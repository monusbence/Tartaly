﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Tartaly
    {
        string nev;
        int a, b, c;
        double aktLiter;
        public Tartaly(string nev)
        {
            this.nev = nev;
            this.a = 10;
            this.b = 10;
            this.c = 10;
            aktLiter = 0;
        }

        public Tartaly(string tartalyNeve, int aOldal, int bOldal, int cOldal)
        {
            this.nev = tartalyNeve;
            this.aktLiter = 0;
            this.a = aOldal;
            this.b = bOldal;
            this.c = cOldal;

        }

        public double Terfogat
        {
            get { return this.a * this.b * this.c; }
        }

        public void DuplazMeretet()
        {
            this.a *= 2;
        }

        public void TeljesLeengedes()
        {
            this.aktLiter = 0;
        }
        public double Toltottseg
        {
            get => (this.aktLiter * 1000 / Terfogat) * 100;
        }

        public void Tolt(double mennyit)
        {

            if (Terfogat / 1000 < this.aktLiter + mennyit)
            {
                Console.WriteLine("Hiba! Túlcsordulás!");
                return;
            }
            this.aktLiter += mennyit;
        }


        public string Info()
        {
            return $"{this.nev}: {this.Terfogat * 1000:n1} cm3 = ({this.Terfogat:n2} liter)," +
                $" töltöttsége: {this.Toltottseg:n2}%, ({this.aktLiter:n2} liter)," +
                $" méretei: {this.a}x{this.b}x{this.c} cm";

            
            return string.Format("{0}: {1} cm3 = ({6} liter), töltöttsége: {2}%, ({7} liter), méretei: {3}x{4}x{5} cm"
                , this.nev
                , this.Terfogat
                , this.Toltottseg
                , this.a
                , this.b
                , this.c
                , this.Terfogat / 1000
                , this.aktLiter
                );
            

        }
    }
}
    
